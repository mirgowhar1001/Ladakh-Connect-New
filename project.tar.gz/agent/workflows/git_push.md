---
description: Push changes to git
---
1. env:
    GIT_SSL_NO_VERIFY: "true"
2. git add .
3. git commit -m "Update OwnerDashboard: Add Edit Profile & Fix Confirm Logic"
4. git push origin main
